import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OnlineTestTest extends OnlineTest {

	@Test
	void testOnlineTest() {
		fail("Not yet implemented");
	}

	@Test
	void testActionPerformed() {
		fail("Not yet implemented");
	}

	@Test
	void testSet() {
		fail("Not yet implemented");
	}

	@Test
	void testCheck() {
		assertTrue(jb[1].isSelected());
	}

	@Test
	void testMain() {
		fail("Not yet implemented");
	}

}
